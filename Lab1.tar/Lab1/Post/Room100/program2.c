/*
This is program compiles perfectly the function
is defined before it is called.
*/

void hello()
{
printf("Hello world\n");
}

main()
{
hello();
}

